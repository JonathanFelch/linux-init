.. documentation master file, created by
   sphinx-quickstart on Thu Dec 19 07:42:57 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

============================================
Welcome to Stat Arb's cluster documentation!
============================================

Introduction
~~~~~~~~~~~~
The Software:

  * Joblib
  * Cluster Client
  * Thunks
  * Notebooks


The Infrastructure:  Two Clusters

  * HPC
  * Condor


The Software
~~~~~~~~~~~~~

Job Lib 
-------

Cluster Clients
---------------

Thunks
------

Notebooks
---------

   
The Clusters 
~~~~~~~~~~~~

HPC Cluster
-----------

Condor Cluster
--------------

   
References
~~~~~~~~~~~~~~~


The project provides two -- possibly three -- implementations including 
the original R code and a similar library using Scala and the Saddle library
which provides R-like DataFrames to Scala.

.. _R: http://cran.us.r-project.org/

.. _Scala: http://www.scala-lang.org/
.. _Saddle: http://saddle.github.io/

In both cases the tool set includes a mechanism    

Scala
-----

The scala implementation has three first class types which are the basis for the model and design:

- Generators
- Bidders
- Auctions

GNU R
-----

The GNU R Language implementation consists of a number of functions written by Media Crossing and complete
as part of an evalutation process.


Getting Started
~~~~~~~~~~~~~~~

Most of the opportunity to review, expand, and experiment with the toolkit is contained in the scripts
directory.  The GNU R scripts can simply be sourced from RStudio.  The Scala scripts are best run
from the SBT console using the ::load XYZ syntax.




References, Links, Copyrights
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


Saddle Dependencies
-------------------

Saddle relies in whole or in part on some great open source software. It is
well worth the time to explore these libraries. All libraries are licensed
under one of: Apache 2.0, BSD-style, or LGPL. To satisfy the LGPL, Saddle
minimizes coupling so replacing the dependency should be trivial.

- `Joda Time`_
- `EJML`_
- `Apache Commons Math`_
- `FastUtil`_
- `DsiUtils`_
- `HDF5`_

.. _`Joda Time`: http://joda-time.sourceforge.net/
.. _`EJML`: http://code.google.com/p/efficient-java-matrix-library/
.. _`Apache Commons Math`: http://commons.apache.org/proper/commons-math/
.. _`FastUtil`: http://fastutil.di.unimi.it/
.. _`DsiUtils`: http://dsiutils.di.unimi.it/
.. _`HDF5`: http://www.hdfgroup.org/HDF5/
   
Copyrights
----------


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

